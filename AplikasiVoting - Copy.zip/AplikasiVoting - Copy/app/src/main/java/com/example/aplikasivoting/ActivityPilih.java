package com.example.aplikasivoting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ActivityPilih extends AppCompatActivity {

    Button candidatBtn;
    Button candidat2Btn;

    TextView candidatText;
    TextView candidat2Text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pilih);

        candidatText = findViewById(R.id.tv_candidat_count);

        candidat2Text = findViewById(R.id.tv_candidat2_count);


        candidatBtn = findViewById(R.id.btn_candidat_vote);
        candidat2Btn = findViewById(R.id.btn_candidat_vote);
    }

    public void oncandidatClicked(View v){
        String candidatCount = candidatText.getText().toString().trim();
        int count = Integer.parseInt(candidatCount);
        count++;
        candidatText.setText(String.valueOf(count));
    }

    public void oncandidat2Clicked(View v){
        String candidat2Count = candidat2Text.getText().toString().trim();
        int count = Integer.parseInt(candidat2Count);
        count++;
        candidat2Text.setText(String.valueOf(count));
    }
    public void SDK(View view) {
        Intent intent = new Intent(ActivityPilih.this, ActivityAwal.class);
        startActivity(intent);
    }

}