package com.example.aplikasivoting;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddPenggunaActivity extends AppCompatActivity {
    private Button addTodoBtn;
    private EditText kelasEditText;
    private EditText namaEditText;
    private DBManager dbManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_pengguna);
        kelasEditText = (EditText) findViewById(R.id.kelas_edittext);
        namaEditText = (EditText) findViewById(R.id.nama_edittext);
        addTodoBtn = (Button) findViewById(R.id.add_record);
        // Membuat objek dari kelas DBManager
        dbManager = new DBManager(this);
        dbManager.open();
    }
    public void save(View view) {
        // Mengambil data inputan user
        final String kelas = kelasEditText.getText().toString();
        final String nama = namaEditText.getText().toString();
 /* Memanggil fungsi insert melalui objek dbManager dengan parameter
 nilaikelas dan nama */
        dbManager.insert(kelas, nama);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        alert.setMessage("Pastikan anda sudah mengisi nama dan kelas sebagai pendataan ABSEN!!!");

        alert.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg1, int arg2) {
                Toast.makeText(AddPenggunaActivity.this, "Silahkan Klik tombol Pilih untuk Melanjutkan", Toast.LENGTH_LONG) .show();
            }
        });
        alert.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg1, int arg2) {
                Toast.makeText(AddPenggunaActivity.this, "Silahkan Isi kembali, atau hubungi panitia", Toast.LENGTH_LONG) .show();
            }
        });

        AlertDialog alertDialog = alert.create();

        alertDialog.show();

    }
    public void  Pilih(){
        Intent inten = new Intent(AddPenggunaActivity.this, ActivityPilih.class);
        startActivity(inten);
    }
    public void Bantuan(View view) {
        Intent intent = new Intent(AddPenggunaActivity.this, ActivityBantuan.class);
        startActivity(intent);
    }

}
