package com.example.aplikasivoting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityBantuan extends AppCompatActivity { @Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState); setContentView(R.layout.activity_bantuan);
    Button btnSend = (Button) findViewById(R.id.sendMail); btnSend.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) { // Membuat objek Intent
            Intent si = new Intent(Intent.ACTION_SEND);
            // Mengatur MIME Type
            si.setType("message/rfc822");
            // Mengatur data nilai untuk Alamat E-Mail
            si.putExtra(Intent.EXTRA_EMAIL, new String[]{"denanto01@gmail.com"});
            // Mengatur data nilai untuk Subject E-Mail
            si.putExtra(Intent.EXTRA_SUBJECT, "Mohon Bantu saya");
            // Mengatur data nilai untuk Badan E-Mail
            si.putExtra(Intent.EXTRA_TEXT, "Hi Admin, saya mengalami kendala. Mohon hampiri saya");
            /* Menjalankan Activity dengan parameter fungsi createChooser dengan parameter objek Intent */
            startActivity(Intent.createChooser(si, "Choose Mail App")); }
    }); }
}

